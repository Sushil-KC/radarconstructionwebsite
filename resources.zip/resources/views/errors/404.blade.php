<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-EVSTQN3/azprG1Anm3QDgpJLIm9Nao0Yz1ztcQTwFspd3yD65VohhpuuCOmLASjC" crossorigin="anonymous">
<style>
    
</style>
<!-- shop begin -->
 <div class="error pt-5 pb-5">
        <div class="container">
            <div class="row">
                <div class="col-xl-12">
                    <div class="error-content-wrapper text-center">
                        <img src="{{asset('./frontend/assets/img/logo/error.png')}}" alt="img">
                        <h2 class="error-title mt-30">Page Not Found!</h2>
                        <p>Please try searching for some other page.</p>
                        <div class="error-button pt-15 text-center">
                            <a href="{{route('/')}}" class="btn btn-primary">Back To Home</a>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!-- shop end -->